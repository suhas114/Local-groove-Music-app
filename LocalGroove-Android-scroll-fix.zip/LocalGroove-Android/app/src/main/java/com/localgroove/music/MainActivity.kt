package com.localgroove.music

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

private val Ink = Color(0xFF0D0E12)
private val Panel = Color(0xFF191B22)
private val Lime = Color(0xFFC7F36B)
private val Muted = Color(0xFF9A9CAB)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LocalGrooveTheme {
                MusicHome(
                    context = this,
                    onStartService = { connectPlaybackService() },
                    controllerProvider = { controllerFuture?.let { if (it.isDone && !it.isCancelled) runCatching { it.get() }.getOrNull() else null } }
                )
            }
        }
    }

    private fun connectPlaybackService() {
        if (controllerFuture != null) return
        val intent = Intent(this, PlaybackService::class.java)
        ContextCompat.startForegroundService(this, intent)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun LocalGrooveTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Lime, onPrimary = Ink, background = Ink, onBackground = Color.White,
        surface = Panel, onSurface = Color.White, secondary = Lime, onSurfaceVariant = Muted
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MusicHome(
    context: Context,
    onStartService: () -> Unit,
    controllerProvider: () -> MediaController?
) {
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }
    var activeFilter by remember { mutableStateOf<Pair<String, String>?>(null) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var playingId by remember { mutableStateOf<Long?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) songs = MusicRepository.loadSongs(context)
    }

    LaunchedEffect(Unit) {
        onStartService()
        if (permissionGranted) songs = MusicRepository.loadSongs(context)
    }
    LaunchedEffect(Unit) {
        repeat(30) {
            val found = controllerProvider()
            if (found != null) {
                controller = found
                return@LaunchedEffect
            }
            kotlinx.coroutines.delay(100)
        }
    }
    DisposableEffect(controller) {
        val c = controller
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                playingId = mediaItem?.mediaId?.toLongOrNull()
            }
        }
        c?.addListener(listener)
        onDispose { c?.removeListener(listener) }
    }

    val visibleSongs = remember(songs, query, activeFilter) {
        songs.filter { song ->
            val matchesQuery = listOf(song.title, song.artist, song.composer, song.album)
                .any { it.contains(query, ignoreCase = true) }
            val matchesFilter = activeFilter?.let { (field, value) ->
                when (field) { "artist" -> song.artist == value; "composer" -> song.composer == value; else -> true }
            } ?: true
            matchesQuery && matchesFilter
        }
    }
    val artists = remember(songs) { songs.map { it.artist }.filter { it != "Unknown singer" }.distinct().sorted() }
    val composers = remember(songs) { songs.map { it.composer }.filter { it != "Unknown composer" }.distinct().sorted() }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("♫  LocalGroove", fontWeight = FontWeight.ExtraBold, color = Lime)
                        Text("YOUR MUSIC. YOUR RULES.", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                },
                actions = {
                    IconButton(onClick = { if (permissionGranted) songs = MusicRepository.loadSongs(context) else permissionLauncher.launch(audioPermission()) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Rescan music", tint = Lime)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        },
        bottomBar = {
            MiniPlayer(
                song = songs.firstOrNull { it.id == playingId },
                isPlaying = isPlaying,
                onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                onPrevious = { controller?.seekToPreviousMediaItem() },
                onNext = { controller?.seekToNextMediaItem() }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("YOUR OFFLINE MUSIC PLAYER", color = Lime, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("All your music.\nYour kind of shuffle.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Text("Local songs only. No ads, no streaming, no distractions.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { shuffleSongs(songs, controller) }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink), modifier = Modifier.weight(1f)) {
                            Text("⤨  Shuffle all", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = { activeFilter = null; selectedTab = 0 }, modifier = Modifier.weight(1f)) { Text("Library", color = Lime) }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("SONGS", songs.size.toString(), Modifier.weight(1f))
                StatCard("SINGERS", artists.size.toString(), Modifier.weight(1f))
                StatCard("COMPOSERS", composers.size.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Songs", "Singers", "Composers").forEachIndexed { index, title ->
                    Card(
                        modifier = Modifier.weight(1f).clickable { selectedTab = index; activeFilter = null },
                        colors = CardDefaults.cardColors(containerColor = if (selectedTab == index) Lime else Panel),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                title,
                                color = if (selectedTab == index) Ink else Color.White,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                when (index) { 0 -> songs.size.toString(); 1 -> artists.size.toString(); else -> composers.size.toString() },
                                color = if (selectedTab == index) Ink else Muted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (selectedTab == 0) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search songs, singers, composers…", color = Muted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) }, singleLine = true,
                    shape = RoundedCornerShape(12.dp), colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Lime, unfocusedBorderColor = Panel, focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (activeFilter == null) "YOUR LIBRARY" else "FILTERED SHUFFLE", color = Muted, style = MaterialTheme.typography.labelSmall)
                    TextButton(onClick = { shuffleSongs(visibleSongs, controller) }) { Text("⤨ Shuffle list", color = Lime) }
                }
                if (!permissionGranted) PermissionCard { permissionLauncher.launch(audioPermission()) }
                else if (songs.isEmpty()) EmptyCard(onRescan = { songs = MusicRepository.loadSongs(context) })
                else if (visibleSongs.isEmpty()) Text("No songs match this search.", color = Muted, modifier = Modifier.padding(16.dp))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(visibleSongs, key = { it.id }) { song ->
                        SongRow(song, isCurrent = song.id == playingId, onClick = { playSongs(songs, song, controller) })
                    }
                }
            } else {
                val list = if (selectedTab == 1) artists else composers
                val field = if (selectedTab == 1) "artist" else "composer"
                if (list.isEmpty()) {
                    EmptyCard(onRescan = { songs = MusicRepository.loadSongs(context) }, message = "No ${if (field == "artist") "singer" else "composer"} tags found. Check your music metadata.")
                } else LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(list) { name ->
                        val count = songs.count { if (field == "artist") it.artist == name else it.composer == name }
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                            Row(Modifier.fillMaxWidth().clickable {
                                activeFilter = field to name
                                val matched = songs.filter { if (field == "artist") it.artist == name else it.composer == name }
                                shuffleSongs(matched, controller)
                                selectedTab = 0
                            }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text("$count songs · tap to shuffle", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                                Text("⤨", color = Lime, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun shuffleSongs(list: List<Song>, controller: MediaController?) {
    if (list.isEmpty() || controller == null) return
    val shuffled = list.shuffled()
    controller.setMediaItems(shuffled.map { it.toMediaItem() })
    controller.prepare()
    controller.play()
}

private fun playSongs(all: List<Song>, selected: Song, controller: MediaController?) {
    if (controller == null) return
    val ordered = listOf(selected) + all.filter { it.id != selected.id }
    controller.setMediaItems(ordered.map { it.toMediaItem() })
    controller.prepare()
    controller.play()
}

private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).setComposer(composer).build()
    ).build()

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Lime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SongRow(song: Song, isCurrent: Boolean, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = if (isCurrent) Color(0xFF252C20) else Panel), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFF282B35), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = Lime)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = if (isCurrent) Lime else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${song.artist} · ${song.composer}", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(formatDuration(song.durationMs), color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun MiniPlayer(song: Song?, isPlaying: Boolean, onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit) {
    Surface(color = Panel, tonalElevation = 6.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFF282B35), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = Lime)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: "Nothing playing yet", color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "Choose a song", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
            IconButton(onClick = onPlayPause) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Lime, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
        }
    }
}

@Composable
private fun PermissionCard(onGrant: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("Let LocalGroove find your music", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Allow audio access so the app can list songs stored on your phone. Your music stays on your device.", color = Muted)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text("Allow music access") }
        }
    }
}

@Composable
private fun EmptyCard(onRescan: () -> Unit, message: String = "Put audio files on your phone, then rescan your music library.") {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(8.dp))
            Text("Your music starts here", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(message, color = Muted)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onRescan) { Text("Rescan library", color = Lime) }
        }
    }
}

private fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt().coerceAtLeast(0)
    return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
}
