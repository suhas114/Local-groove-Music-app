# LocalGroove for Android

A native offline Android music player built with Kotlin, Jetpack Compose, and AndroidX Media3. LocalGroove scans the device's indexed music library and plays local audio; it does not require an account or streaming service.

## Included in this UI refresh
- Reworked dark UI with lime accents and a custom vector launcher icon.
- Dedicated Home, Songs, Artists, Albums, and More destinations; Composers are accessible from More.
- Independently searchable song, artist, composer, album, favorite, and recent lists.
- LazyColumn-backed music lists so the list owns vertical scrolling and can reach the final item without being covered by the fixed mini-player/navigation bar.
- Persistent favorites and recently played IDs using local app preferences.
- Mini-player and full-screen player with play/pause, previous/next, seek, shuffle, and favorite controls.
- Rescan control, permission explanation, and empty-state guidance.
- Local-only playback, no ads or analytics SDK, and no Internet permission.

## Build APK
Recommended: Android Studio Ladybug or newer, JDK 17, Android SDK Platform 35.

1. Extract this ZIP and open the `LocalGroove-Android` directory in Android Studio.
2. Let Gradle sync finish and install requested SDK components.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The repository's GitHub Actions workflow can also build the debug APK and publish it as a downloadable artifact when the ZIP is committed under the expected name `LocalGroove-Android-source.zip`.

## Metadata notes
Artist, composer, and album sections depend on tags provided by Android MediaStore. Tracks with missing metadata may not appear under named artist/composer/album groups. Audio access permission is required.

## Verification status
This is an updated source package. It has not been compiled or tested on a physical Android device in this environment. In particular, confirm build success and test scrolling, audio playback, seek controls, and permission handling on-device before treating it as a release. Playlist creation and album-art extraction are not implemented in this revision; playlists are currently identified as a future enhancement in the app.
