# LocalGroove for Android 🎵

Native Android offline music player written in Kotlin + Jetpack Compose. This is **not a browser app**.

## Features
- Reads audio indexed by Android MediaStore from the device's music library.
- Browse songs, singers/artists, and composers.
- Shuffle the whole library, filtered search results, or one singer/composer.
- Background playback using AndroidX Media3 `MediaSessionService`.
- Android media session integration for system playback controls/notification.
- Dark UI with lime-green accent, no ad SDK, no analytics, no network permission.
- Local playback only; the app does not upload music.

## Build an APK
Recommended: Android Studio Ladybug or newer, JDK 17, Android SDK Platform 35.

1. Extract/open this project folder in Android Studio.
2. Allow Gradle sync and install the required Android SDK packages when prompted.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK output should be at `app/build/outputs/apk/debug/app-debug.apk`.
5. On your Android phone, transfer the APK and install it. You may need to allow installation from that file manager.

Command line (after installing Android SDK and Gradle):
```bash
gradle assembleDebug
```
The APK output path is `app/build/outputs/apk/debug/app-debug.apk`.

## Push to GitHub
1. Create an empty repository at https://github.com/new, for example `LocalGroove-Android`.
2. Open a terminal in this extracted project folder:
```bash
git init
git add .
git commit -m "Build LocalGroove native Android music player"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/LocalGroove-Android.git
git push -u origin main
```
Replace `YOUR_USERNAME` with your GitHub username. Authenticate with GitHub when prompted. Never put a personal access token in the source code.

## Music metadata
Singer/composer grouping depends on metadata indexed by Android MediaStore. Many audio files have an artist tag but no composer tag. Those tracks are shown under “Unknown composer”. Edit the file's tags using a music tag editor if necessary.

## Permissions and privacy
The app requests only Android audio-library access (and declares foreground media playback). It does not request Internet permission and contains no ad SDK. Android version and device settings determine whether notification permission is also requested by the OS. The source declares notification permission but the first version does not yet show an in-app notification permission prompt.

## Current delivery status
This package is GitHub-ready source code. An APK has not been compiled or device-tested in this environment because the Android SDK/Gradle build toolchain is not installed here. Build it using Android Studio steps above to produce a real installable APK.
