package com.localgroove.music

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay

private val Ink = Color(0xFF0C0E12)
private val Panel = Color(0xFF181B22)
private val PanelRaised = Color(0xFF222630)
private val Lime = Color(0xFFC8F36A)
private val Muted = Color(0xFF9CA3B4)

private enum class Destination(val label: String) {
    Home("Home"), Songs("Songs"), Artists("Artists"), Composers("Composers"), Albums("Albums"), More("More")
}

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LocalGrooveTheme {
                MusicHome(
                    context = this,
                    onStartService = { connectPlaybackService() },
                    controllerProvider = { controllerFuture?.let { if (it.isDone && !it.isCancelled) runCatching { it.get() }.getOrNull() else null } }
                )
            }
        }
    }

    private fun connectPlaybackService() {
        if (controllerFuture != null) return
        ContextCompat.startForegroundService(this, Intent(this, PlaybackService::class.java))
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun LocalGrooveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Lime, onPrimary = Ink, background = Ink, onBackground = Color.White,
            surface = Panel, onSurface = Color.White, secondary = Lime, onSurfaceVariant = Muted),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MusicHome(context: Context, onStartService: () -> Unit, controllerProvider: () -> MediaController?) {
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var destination by remember { mutableStateOf(Destination.Home) }
    var search by remember { mutableStateOf("") }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var playingId by remember { mutableStateOf<Long?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var showPlayer by remember { mutableStateOf(false) }
    var selectedCollection by remember { mutableStateOf<Pair<String, String>?>(null) }
    var moreMode by remember { mutableStateOf("menu") }
    var favorites by remember { mutableStateOf(loadIdSet(context, "favorites")) }
    var recentIds by remember { mutableStateOf(loadIdList(context, "recent")) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) songs = MusicRepository.loadSongs(context)
    }

    LaunchedEffect(Unit) {
        onStartService()
        if (permissionGranted) songs = MusicRepository.loadSongs(context)
    }
    LaunchedEffect(Unit) {
        repeat(40) {
            val found = controllerProvider()
            if (found != null) { controller = found; return@LaunchedEffect }
            delay(100)
        }
    }
    DisposableEffect(controller) {
        val player = controller
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId?.toLongOrNull()
                playingId = id
                if (id != null) {
                    recentIds = (listOf(id) + recentIds.filterNot { it == id }).take(100)
                    saveIdList(context, "recent", recentIds)
                }
            }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }
    LaunchedEffect(controller, isPlaying) {
        while (true) {
            controller?.let {
                currentPosition = it.currentPosition.coerceAtLeast(0L)
                duration = it.duration.takeIf { d -> d > 0 } ?: songs.firstOrNull { s -> s.id == playingId }?.durationMs ?: 0L
            }
            delay(if (isPlaying) 500 else 1200)
        }
    }

    val artists = remember(songs) { songs.map { it.artist }.filter { it.isNotBlank() && it != "Unknown singer" }.distinct().sorted() }
    val composers = remember(songs) { songs.map { it.composer }.filter { it.isNotBlank() && it != "Unknown composer" }.distinct().sorted() }
    val albums = remember(songs) { songs.map { it.album }.filter { it.isNotBlank() && it != "Unknown album" }.distinct().sorted() }
    val selectedSongs = remember(songs, destination, search, selectedCollection, favorites, recentIds, moreMode) {
        val base = when {
            selectedCollection?.first == "artist" -> songs.filter { it.artist == selectedCollection?.second }
            selectedCollection?.first == "composer" -> songs.filter { it.composer == selectedCollection?.second }
            selectedCollection?.first == "album" -> songs.filter { it.album == selectedCollection?.second }
            destination == Destination.Artists -> emptyList()
            destination == Destination.Composers -> emptyList()
            destination == Destination.Albums -> emptyList()
            destination == Destination.More && moreMode == "favorites" -> songs.filter { it.id in favorites }
            destination == Destination.More && moreMode == "recent" -> recentIds.mapNotNull { id -> songs.find { it.id == id } }
            else -> songs
        }
        base.filter { song -> listOf(song.title, song.artist, song.album, song.composer).any { it.contains(search, true) } }
    }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                navigationIcon = {
                    Box(Modifier.padding(start = 12.dp).size(38.dp).background(Lime, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MusicNote, contentDescription = "LocalGroove logo", tint = Ink, modifier = Modifier.size(25.dp))
                    }
                },
                title = {
                    Column {
                        Text("LocalGroove", fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text(destination.label.uppercase(), color = Lime, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    IconButton(onClick = { if (permissionGranted) songs = MusicRepository.loadSongs(context) else permissionLauncher.launch(audioPermission()) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Rescan library", tint = Lime)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        },
        bottomBar = {
            Column {
                MiniPlayer(
                    song = songs.firstOrNull { it.id == playingId }, isPlaying = isPlaying,
                    onOpen = { showPlayer = true },
                    onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                    onPrevious = { controller?.seekToPreviousMediaItem() }, onNext = { controller?.seekToNextMediaItem() }
                )
                NavigationBar(containerColor = Panel, contentColor = Color.White, tonalElevation = 0.dp) {
                    val navItems = listOf(Destination.Home, Destination.Songs, Destination.Artists, Destination.Albums, Destination.More)
                    navItems.forEach { item ->
                        NavigationBarItem(
                            selected = destination == item,
                            onClick = { destination = item; selectedCollection = null; search = ""; moreMode = "menu" },
                            icon = { Icon(when (item) { Destination.Home -> Icons.Default.Home; Destination.Songs -> Icons.Default.LibraryMusic; Destination.Artists -> Icons.Default.MusicNote; Destination.Albums -> Icons.Default.Album; else -> Icons.Default.Tune }, contentDescription = item.label) },
                            label = { Text(item.label, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Ink, selectedTextColor = Lime, indicatorColor = Lime, unselectedIconColor = Muted, unselectedTextColor = Muted)
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (!permissionGranted) {
                PermissionCard { permissionLauncher.launch(audioPermission()) }
            } else if (songs.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.TopCenter) {
                    EmptyCard(onRescan = { songs = MusicRepository.loadSongs(context) }, message = "Add audio files to your phone, then scan your library.")
                }
            } else {
                when {
                    selectedCollection != null -> {
                        CollectionScreen(
                            title = selectedCollection!!.second,
                            songs = selectedSongs,
                            playingId = playingId,
                            search = search,
                            onSearch = { search = it },
                            onBack = { selectedCollection = null; search = "" },
                            onPlay = { playSongs(selectedSongs, it, controller) }
                        )
                    }
                    destination == Destination.Home -> HomeScreen(
                        songs = songs,
                        recent = recentIds.mapNotNull { id -> songs.find { it.id == id } },
                        favoriteCount = favorites.size,
                        onOpenSongs = { destination = Destination.Songs },
                        onOpenRecent = { destination = Destination.More; moreMode = "recent"; search = "" },
                        onOpenFavorites = { destination = Destination.More; moreMode = "favorites"; search = "" },
                        onPlay = { playSongs(songs, it, controller) },
                        onShuffle = { shuffleSongs(songs, controller) }
                    )
                    destination == Destination.Songs -> SongLibraryScreen(
                        title = "All songs", songs = selectedSongs, playingId = playingId, search = search,
                        onSearch = { search = it }, onPlay = { playSongs(selectedSongs, it, controller) },
                        onShuffle = { shuffleSongs(selectedSongs, controller) }, favorites = favorites,
                        onToggleFavorite = { song -> favorites = toggleId(context, favorites, song.id) }
                    )
                    destination == Destination.Artists -> CategoryScreen(
                        title = "Singers & artists", subtitle = "Browse tracks by artist", query = search,
                        onQuery = { search = it }, names = artists.filter { it.contains(search, true) },
                        songs = songs, field = "artist", onSelect = { selectedCollection = "artist" to it; search = "" }
                    )
                    destination == Destination.Composers -> CategoryScreen(
                        title = "Composers", subtitle = "Find music by composer", query = search,
                        onQuery = { search = it }, names = composers.filter { it.contains(search, true) },
                        songs = songs, field = "composer", onSelect = { selectedCollection = "composer" to it; search = "" }
                    )
                    destination == Destination.Albums -> CategoryScreen(
                        title = "Albums", subtitle = "Browse your album collection", query = search,
                        onQuery = { search = it }, names = albums.filter { it.contains(search, true) },
                        songs = songs, field = "album", onSelect = { selectedCollection = "album" to it; search = "" }
                    )
                    else -> MoreScreen(
                        favoritesCount = favorites.size, recentCount = recentIds.size,
                        onFavorites = { moreMode = "favorites"; search = "" }, onRecent = { moreMode = "recent"; search = "" },
                        onComposers = { destination = Destination.Composers; moreMode = "menu"; search = "" },
                        mode = moreMode, onBack = { moreMode = "menu"; search = "" },
                        songs = selectedSongs, playingId = playingId, onPlay = { playSongs(selectedSongs, it, controller) },
                        favorites = favorites, onToggleFavorite = { song -> favorites = toggleId(context, favorites, song.id) },
                        search = search, onSearch = { search = it }
                    )
                }
            }
        }
    }

    if (showPlayer) {
        FullPlayerDialog(
            song = songs.firstOrNull { it.id == playingId }, isPlaying = isPlaying,
            position = currentPosition, duration = duration,
            isFavorite = playingId != null && playingId in favorites,
            onDismiss = { showPlayer = false },
            onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
            onPrevious = { controller?.seekToPreviousMediaItem() }, onNext = { controller?.seekToNextMediaItem() },
            onSeek = { controller?.seekTo(it) },
            onFavorite = { id -> if (id != null) favorites = toggleId(context, favorites, id) },
            onShuffle = { shuffleSongs(songs, controller) }
        )
    }
}

@Composable
private fun HomeScreen(
    songs: List<Song>, recent: List<Song>, favoriteCount: Int,
    onOpenSongs: () -> Unit, onOpenRecent: () -> Unit, onOpenFavorites: () -> Unit,
    onPlay: (Song) -> Unit, onShuffle: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("GOOD MUSIC, CLOSE BY", color = Lime, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Your library,\nyour way.", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("${songs.size} local songs · plays offline", color = Muted)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onShuffle, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle all")
                        }
                        OutlinedButton(onClick = onOpenSongs, modifier = Modifier.weight(1f)) { Text("Browse songs", color = Lime) }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryTile("Songs", songs.size.toString(), Icons.Default.LibraryMusic, Modifier.weight(1f), onOpenSongs)
                SummaryTile("Favorites", favoriteCount.toString(), Icons.Default.Favorite, Modifier.weight(1f), onOpenFavorites)
                SummaryTile("Recent", recent.size.toString(), Icons.Default.Refresh, Modifier.weight(1f), onOpenRecent)
            }
        }
        item { SectionHeading("Recently played", action = "View all", onAction = onOpenRecent) }
        if (recent.isEmpty()) item { InfoCard("Your listening history appears here", "Play a song and it will show up in Recently Played.") }
        else items(recent.take(8), key = { "recent-${it.id}" }) { song -> SongRow(song, isCurrent = false, onClick = { onPlay(song) }) }
    }
}

@Composable
private fun SongLibraryScreen(
    title: String, songs: List<Song>, playingId: Long?, search: String, onSearch: (String) -> Unit,
    onPlay: (Song) -> Unit, onShuffle: () -> Unit, favorites: Set<Long>, onToggleFavorite: (Song) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        SearchField(search, onSearch, "Search title, artist or album")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("${songs.size} tracks", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = Lime); Spacer(Modifier.width(4.dp)); Text("Shuffle", color = Lime) }
        }
        if (songs.isEmpty()) EmptyMessage("No songs match your search", "Try another title, artist or album.")
        else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(songs, key = { it.id }) { song ->
                SongRow(song, isCurrent = song.id == playingId, isFavorite = song.id in favorites,
                    onClick = { onPlay(song) }, onFavorite = { onToggleFavorite(song) })
            }
        }
    }
}

@Composable
private fun CollectionScreen(title: String, songs: List<Song>, playingId: Long?, search: String, onSearch: (String) -> Unit, onBack: () -> Unit, onPlay: (Song) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Lime) }
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text("${songs.size} songs", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        SearchField(search, onSearch, "Search within this collection")
        if (songs.isEmpty()) EmptyMessage("No matching tracks", "Try changing the search.")
        else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(songs, key = { it.id }) { song -> SongRow(song, song.id == playingId, onClick = { onPlay(song) }) }
        }
    }
}

@Composable
private fun CategoryScreen(title: String, subtitle: String, query: String, onQuery: (String) -> Unit, names: List<String>, songs: List<Song>, field: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
        SearchField(query, onQuery, "Search ${title.lowercase()}")
        if (names.isEmpty()) EmptyMessage("Nothing found", "This list uses tags from music files on your phone.")
        else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names, key = { "$field-$it" }) { name ->
                val count = songs.count { when (field) { "artist" -> it.artist == name; "composer" -> it.composer == name; else -> it.album == name } }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().clickable { onSelect(name) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).background(PanelRaised, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(if (field == "album") Icons.Default.Album else Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("$count ${if (count == 1) "song" else "songs"}", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("›", color = Lime, style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun MoreScreen(
    favoritesCount: Int, recentCount: Int, onFavorites: () -> Unit, onRecent: () -> Unit, onComposers: () -> Unit,
    mode: String, onBack: () -> Unit, songs: List<Song>, playingId: Long?, onPlay: (Song) -> Unit,
    favorites: Set<Long>, onToggleFavorite: (Song) -> Unit, search: String, onSearch: (String) -> Unit
) {
    if (mode == "menu") {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("Your music", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
            item { CollectionShortcut("♥", "Favorites", "$favoritesCount saved songs", onFavorites) }
            item { CollectionShortcut("◷", "Recently played", "$recentCount recent tracks", onRecent) }
            item { CollectionShortcut("♫", "Composers", "Browse tracks by composer", onComposers) }
            item { InfoCard("Playlists", "Playlist management is not included in this build yet. Favorites gives you a saved collection of tracks.") }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Lime); Text("More", color = Lime) }
                Text(if (mode == "favorites") "Favorites" else "Recently played", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            }
            SearchField(search, onSearch, "Filter this list")
            if (songs.isEmpty()) EmptyMessage("No songs here yet", "Play music or mark songs as favorites to fill this list.")
            else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(songs, key = { "more-${it.id}" }) { song -> SongRow(song, song.id == playingId, song.id in favorites, { onPlay(song) }, { onToggleFavorite(song) }) }
            }
        }
    }
}

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value.takeUnless { it.startsWith("__") } ?: "", onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        placeholder = { Text(hint, color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
        trailingIcon = { if (value.isNotEmpty() && !value.startsWith("__")) TextButton(onClick = { onValueChange("") }) { Text("Clear", color = Lime) } },
        singleLine = true, shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Lime, unfocusedBorderColor = PanelRaised, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Lime)
    )
}

@Composable
private fun SummaryTile(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Icon(icon, null, tint = Lime, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(8.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text(label, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}

@Composable
private fun SectionHeading(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) TextButton(onClick = onAction) { Text(action, color = Lime) }
    }
}

@Composable
private fun CollectionShortcut(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(PanelRaised, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(icon, color = Lime, style = MaterialTheme.typography.titleLarge) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall) }
            Text("›", color = Lime, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(body, color = Muted, style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable
private fun EmptyMessage(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(10.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp)); Text(body, color = Muted)
    }
}

@Composable
private fun SongRow(song: Song, isCurrent: Boolean, isFavorite: Boolean = false, onClick: () -> Unit, onFavorite: (() -> Unit)? = null) {
    Card(colors = CardDefaults.cardColors(containerColor = if (isCurrent) Color(0xFF252D20) else Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(horizontal = 11.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(PanelRaised, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = if (isCurrent) Lime else Muted, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = if (isCurrent) Lime else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${song.artist} · ${song.album}", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(formatDuration(song.durationMs), color = Muted, style = MaterialTheme.typography.labelSmall)
            if (onFavorite != null) IconButton(onClick = onFavorite, modifier = Modifier.size(36.dp)) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Toggle favorite", tint = if (isFavorite) Lime else Muted, modifier = Modifier.size(19.dp))
            }
        }
    }
}

@Composable
private fun MiniPlayer(song: Song?, isPlaying: Boolean, onOpen: () -> Unit, onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit) {
    Surface(color = PanelRaised, tonalElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).navigationBarsPadding().padding(start = 12.dp, end = 6.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(Panel, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Lime) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: "Choose a song", color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "Your local library", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
            IconButton(onClick = onPlayPause) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = Lime, modifier = Modifier.size(30.dp)) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
}

@Composable
private fun FullPlayerDialog(song: Song?, isPlaying: Boolean, position: Long, duration: Long, isFavorite: Boolean, onDismiss: () -> Unit,
    onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit, onFavorite: (Long?) -> Unit, onShuffle: () -> Unit) {
    var seekPosition by remember(song?.id) { mutableFloatStateOf(position.toFloat()) }
    LaunchedEffect(position) { seekPosition = position.toFloat() }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.ArrowBack, "Close player", tint = Color.White) }
                    Text("NOW PLAYING", color = Muted, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, "Shuffle all", tint = Lime) }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth().aspectRatio(1f).padding(12.dp).background(PanelRaised, RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(100.dp))
                    }
                    Spacer(Modifier.height(26.dp))
                    Text(song?.title ?: "Nothing playing", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text(song?.artist ?: "Choose a song from your library", color = Muted, style = MaterialTheme.typography.titleMedium)
                }
                Column(Modifier.fillMaxWidth()) {
                    Slider(value = seekPosition.coerceIn(0f, duration.coerceAtLeast(1L).toFloat()), onValueChange = { seekPosition = it }, onValueChangeFinished = { onSeek(seekPosition.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1L).toFloat(), colors = SliderDefaults.colors(thumbColor = Lime, activeTrackColor = Lime))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatDuration(seekPosition.toLong()), color = Muted, style = MaterialTheme.typography.labelSmall); Text(formatDuration(duration), color = Muted, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onFavorite(song?.id) }) { Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite", tint = if (isFavorite) Lime else Muted) }
                        IconButton(onClick = onPrevious, modifier = Modifier.size(54.dp)) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(38.dp)) }
                        FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(70.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Lime, contentColor = Ink)) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", modifier = Modifier.size(38.dp)) }
                        IconButton(onClick = onNext, modifier = Modifier.size(54.dp)) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(38.dp)) }
                        IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, "Shuffle", tint = Lime) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(onGrant: () -> Unit) {
    Card(Modifier.padding(18.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text("Let LocalGroove find your music", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp)); Text("Allow audio access to list songs stored on your phone. Your music stays on your device.", color = Muted)
            Spacer(Modifier.height(12.dp)); Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text("Allow music access") }
        }
    }
}

@Composable
private fun EmptyCard(onRescan: () -> Unit, message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(36.dp)); Spacer(Modifier.height(8.dp))
            Text("Your music starts here", color = Color.White, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp))
            Text(message, color = Muted); Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = onRescan) { Text("Rescan library", color = Lime) }
        }
    }
}

private fun hasAudioPermission(context: Context): Boolean = ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED
private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun shuffleSongs(list: List<Song>, controller: MediaController?) {
    if (list.isEmpty() || controller == null) return
    controller.setMediaItems(list.shuffled().map { it.toMediaItem() }); controller.prepare(); controller.play()
}
private fun playSongs(all: List<Song>, selected: Song, controller: MediaController?) {
    if (controller == null) return
    val ordered = listOf(selected) + all.filter { it.id != selected.id }
    controller.setMediaItems(ordered.map { it.toMediaItem() }); controller.prepare(); controller.play()
}
private fun Song.toMediaItem(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).setComposer(composer).build()).build()

private fun loadIdSet(context: Context, key: String): Set<Long> = context.getSharedPreferences("localgroove", Context.MODE_PRIVATE).getStringSet(key, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
private fun loadIdList(context: Context, key: String): List<Long> = context.getSharedPreferences("localgroove", Context.MODE_PRIVATE).getString(key, "").orEmpty().split(',').mapNotNull { it.toLongOrNull() }
private fun saveIdList(context: Context, key: String, ids: List<Long>) { context.getSharedPreferences("localgroove", Context.MODE_PRIVATE).edit().putString(key, ids.joinToString(",")).apply() }
private fun toggleId(context: Context, current: Set<Long>, id: Long): Set<Long> {
    val next = if (id in current) current - id else current + id
    context.getSharedPreferences("localgroove", Context.MODE_PRIVATE).edit().putStringSet("favorites", next.map { it.toString() }.toSet()).apply()
    return next
}
private fun formatDuration(ms: Long): String { val total = (ms / 1000).toInt().coerceAtLeast(0); return "${total / 60}:${(total % 60).toString().padStart(2, '0')}" }
